<?php

namespace backend\models;


use yii\db\ActiveRecord;

class Settings__list extends ActiveRecord{

}