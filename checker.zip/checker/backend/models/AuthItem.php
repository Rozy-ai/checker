<?php

namespace backend\models;


use yii\db\ActiveRecord;

class AuthItem extends ActiveRecord{

}