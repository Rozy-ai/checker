<?php

namespace backend\models;


class P_all_compare extends \yii\db\ActiveRecord{

  public static function tableName(){
    return 'p_all_compare';
  }






}